def joke():
    return (u'Hello World')
